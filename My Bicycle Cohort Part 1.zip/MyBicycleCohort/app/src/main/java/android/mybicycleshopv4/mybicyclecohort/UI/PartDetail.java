package android.mybicycleshopv4.mybicyclecohort.UI;

import androidx.appcompat.app.AppCompatActivity;
import android.mybicycleshopv4.mybicyclecohort.R;
import android.os.Bundle;

public class PartDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part_detail);
    }
}